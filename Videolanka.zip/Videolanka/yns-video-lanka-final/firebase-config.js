export const firebaseConfig = {
  apiKey: "AIzaSyAbz4g_MriuHe0jZPs1QUjQv-xmFe0Evnw",
  authDomain: "yns-video.firebaseapp.com",
  projectId: "yns-video",
  storageBucket: "yns-video.firebasestorage.app",
  messagingSenderId: "418270284457",
  appId: "1:418270284457:web:a7f08443fdd7f0b7d2b7b8",
  measurementId: "G-26RXZSXC6L"
};

# YNS Video Lanka

## Overview
A Firebase-based video sharing platform with user authentication, referral system, video uploads, and withdrawal requests. Built with vanilla HTML, CSS, and JavaScript using Firebase for backend services.

## Project Structure
```
yns-video-lanka-final/
├── server.py           # Python HTTP server for serving static files
├── firebase-config.js  # Firebase configuration
├── style.css          # Pink-themed UI styles
├── index.html         # Landing page (redirects to login)
├── login.html         # Authentication page
├── dashboard.html     # User dashboard with KPIs and actions
└── videos.html        # Video wall displaying all uploads
```

## Features
- User authentication (login/register) via Firebase Auth
- Referral system with tracking
- Video uploads by URL
- Balance tracking (referrals earn Rs 100 each)
- Withdrawal requests (minimum Rs 500)
- Pink-themed responsive UI

## Setup
- Static HTML/CSS/JS frontend
- Firebase backend (Auth + Firestore)
- Simple Python HTTP server on port 5000
- No build process required

## Recent Changes
- November 10, 2025: Major feature additions
  - **Enhanced Registration**: Added name, phone, address, age, birthday fields to signup
  - **Dashboard Redesign**: Shows referrals list with full details, sidebar for withdrawals
  - **Like/Comment/Share System**: Videos now have social features with earnings (Rs 1/like, Rs 5/comment, Rs 2/share)
  - **Ad Integration**: Pre-roll ads before video playback, banner ads between videos, AdSense placeholders ready
- November 10, 2025: Added file upload capability with Firebase Storage
  - Users can now upload video files directly (with progress bar)
  - Added URL upload option as alternative
  - Both methods save to Firebase Firestore
- November 10, 2025: Initial project setup in Replit environment
  - Configured Python HTTP server with cache control headers
  - Set up workflow for development server
  
## Firebase Security Rules Setup

**වැදගත්! Firebase Console එකෙන් මේ rules set කරන්න අනිවාර්යයි:**

### Firestore Rules
Firebase Console → Firestore Database → Rules → මේ code එක paste කරන්න:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    match /uploads/{uploadId} {
      allow read: if true;
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null && 
        request.auth.uid == resource.data.uid;
    }
    match /withdrawRequests/{requestId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

### Storage Rules
Firebase Console → Storage → Rules → මේ code එක paste කරන්න:

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /videos/{userId}/{fileName} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

### Rules එකතු කිරීමෙන් පසු:
- ✅ Videos upload කරන්න පුළුවන් වෙයි
- ✅ Video Wall එකේ videos පෙන්නනවා
- ✅ Referral system work කරනවා
- ✅ Balance tracking work කරනවා

## Important Notes
- Firebase rules configure කරන තෙක් "Missing or insufficient permissions" error එක පෙන්නනවා
- Rules configure කළ පසු වෙබ්සයිට් refresh කරන්න
- Current setup uses public Firebase configuration (demo purposes only)

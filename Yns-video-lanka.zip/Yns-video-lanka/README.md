# YNS Video Lanka — Final Replit Earning Version

This is a single-file frontend (`index.html`) with Firebase + ImageKit + basic ads overlay + referral + withdraw.
A Netlify Function is included for ImageKit server-side authentication (`netlify/functions/imagekit-auth.js`).

## How to run (Replit or static hosting)
1. Upload the whole ZIP into Replit.
2. Serve `index.html` (e.g., Replit's static server). For Netlify, deploy the repo and enable functions.
3. Ensure the Netlify Function path `/.netlify/functions/imagekit-auth` is reachable (on Netlify, no extra config needed).

## Firebase
- Uses the provided Firebase project config with Auth (Email/Password) + Firestore.
- Firestore Collections used:
  - `users/{uid}`: profile, balance, referral stats
  - `uploads/{autoId}`: uploaded media records
  - `withdrawRequests/{autoId}`: withdraw requests
  - `refEvents/{autoId}`: referral attributions

> **Note:** For true production, set secure Firestore rules. This demo assumes permissive rules for simplicity.

## Referral Flow
- New user opens your site with `?ref=REF_UID` then registers.
- On first login after registration, the app will attribute the referral (once per account) and credit Rs.100 to the referrer.

## ImageKit
- Client requests auth from `/.netlify/functions/imagekit-auth` to securely sign uploads.
- Replace values in the function with your ImageKit PRIVATE key & endpoint if you host elsewhere.

## Ads
- Paste Kadam/Monetag/Adsterra scripts where marked in `index.html`. A simple pre-roll overlay appears before playing uploaded videos.

## Withdraw
- Users can request withdraws via PayPal/Bank/Binance (min Rs.500). Requests go into Firestore for manual review.


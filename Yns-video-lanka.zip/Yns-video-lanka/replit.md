# YNS Video Lanka — Firebase + ImageKit Media Platform

## Overview
YNS Video Lanka is a video/photo sharing platform with earning features. It combines Firebase Authentication & Firestore with ImageKit for media uploads, includes a referral system, withdraw functionality, and ad integration for monetization.

## Recent Changes (November 9, 2025)
- Imported GitHub repository and adapted for Replit environment
- Updated Firebase configuration to use YNS-VIDEO project
- Added Express server to handle ImageKit authentication endpoint
- Integrated PopCash and Monetag ad verification meta tags
- Configured deployment settings for production

## Project Architecture

### Tech Stack
- **Frontend**: Single-page HTML application with vanilla JavaScript
- **Backend**: Node.js Express server (serves static files and handles ImageKit auth)
- **Database**: Firebase Firestore
- **Authentication**: Firebase Auth (Email/Password)
- **Media Storage**: ImageKit CDN
- **Ads**: Monetag, PopCash, Kadam/Adsterra integrations

### File Structure
```
├── index.html           # Main application interface
├── server.js           # Express server with ImageKit auth endpoint
├── package.json        # Node.js dependencies
├── imagekit-auth.js    # Original Netlify function (for reference)
└── README.md          # Original project documentation
```

### Firebase Collections
- `users/{uid}`: User profiles with balance, referral stats, upload count
- `uploads/{autoId}`: Media upload records (URL, type, timestamp)
- `withdrawRequests/{autoId}`: Withdraw requests (pending/approved/rejected)
- `refEvents/{autoId}`: Referral attribution events

### Key Features
1. **Authentication**: Email/password registration and login
2. **Media Upload**: Photos and videos to ImageKit with Firestore tracking
3. **Referral System**: Users earn Rs.100 per successful referral via unique link
4. **Withdraw System**: PayPal/Bank/Binance withdraw requests (minimum Rs.500)
5. **Ad Monetization**: Pre-roll ad overlay before video playback
6. **KPIs Dashboard**: Real-time balance, referral count, and upload tracking

## Configuration

### Environment Variables (Required)
The following **must** be configured in Replit Secrets for the application to work:
- `IMAGEKIT_PRIVATE_KEY`: ImageKit private API key (required for server-side upload authentication)
- `IMAGEKIT_PUBLIC_KEY`: ImageKit public API key (required for client-side SDK)
- `IMAGEKIT_URL_ENDPOINT`: ImageKit URL endpoint (required for media storage)

**Important**: The server will not start without these credentials configured. Add them via the Secrets tab in Replit.

### Current Settings
- **Firebase Project**: yns-video
- **ImageKit Endpoint**: https://ik.imagekit.io/znaoctn4w
- **Server Port**: 5000
- **Host**: 0.0.0.0 (required for Replit)

## Running Locally
The application starts automatically via the configured workflow. The Express server serves the static HTML and provides the ImageKit authentication endpoint at `/.netlify/functions/imagekit-auth`.

## Deployment
The project is configured for Replit Autoscale deployment. Click the "Deploy" button to publish the application with a public URL.

## User Preferences
None specified yet.

## Notes
- Firebase config is embedded in the frontend HTML (public configuration)
- ImageKit credentials are secured in Replit Secrets and never exposed in code
- Ad scripts are included but may require additional setup with ad networks
- Firestore security rules should be configured for production use
- The server will fail to start if ImageKit secrets are not configured

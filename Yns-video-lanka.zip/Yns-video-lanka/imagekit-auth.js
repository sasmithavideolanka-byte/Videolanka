// netlify/functions/imagekit-auth.js
// Serverless signature endpoint for ImageKit. Keeps PRIVATE key off the client.
const crypto = require('crypto');

exports.handler = async (event, context) => {
  // IMPORTANT: In production, read these from environment variables.
  const IMAGEKIT_PRIVATE_KEY = "private_A6MzM1QymfwoZ44vL1LV+0QEw80="; // Provided by user
  const IMAGEKIT_PUBLIC_KEY = "public_2FkgyQIz4e5dnOHMTvFQP3uXVmA=";
  const IMAGEKIT_URL_ENDPOINT = "https://ik.imagekit.io/liqk4bjri";

  try {
    const body = event.httpMethod === 'POST' && event.body ? JSON.parse(event.body) : {};
    const { token, expire } = body;
    if (!token || !expire) {
      return { statusCode: 400, body: JSON.stringify({ error: "token and expire required" }) };
    }
    const signature = crypto
      .createHmac('sha1', IMAGEKIT_PRIVATE_KEY)
      .update(token + expire)
      .digest('hex');

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        signature,
        token,
        expire,
        publicKey: IMAGEKIT_PUBLIC_KEY,
        urlEndpoint: IMAGEKIT_URL_ENDPOINT,
      }),
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
